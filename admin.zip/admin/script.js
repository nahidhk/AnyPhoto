
async function displayData(searchInput = '') {
    try {
  
        
const response = await fetch("https://anyface.readyoffercareer.com/php/user.json"); 
        const data = await response.json();
        const dataContainer = document.getElementById('myapp');


        if (!dataContainer) {
            throw new Error("Element with id 'myapp' not found.");
        }

      
        dataContainer.innerHTML = '';
var adminnameload = localStorage.getItem("adminname")
       
        const filteredData = data.filter(item =>
            item.username.toLowerCase().includes(searchInput.toLowerCase()) ||
            item.title.toLowerCase().includes(searchInput.toLowerCase())
        );

        filteredData.forEach((item, index) => {
            const itemElement = document.createElement('tr');
            itemElement.innerHTML = `
                <td>${item.username}</td>
                <td>${item.date}</td>
                <td>${item.img}</td>
                <td onclick="sendbtnonreport(${index})" style="text-align: center;font-size: 15pt;cursor: pointer;">
                    <i class="bi bi-pencil-square"></i>
                </td>
                <td>
                    <section id="drop-${index}" class="drop vcc" style="display:none;">
                        <div class="mymain">
                            <blockquote>
                                <form action="data.php" method="POST">
                                    <label for="username">Profile Name</label><br>
                                    <input class="inputx" name="username" type="text" value="${item.username}"><br>
                                    <label for="date">Date</label><br>
                                    <input class="inputx" name="date" type="text" value="${item.date}"><br>
                                    <label for="img">Photo ID</label><br>
                                    <input class="inputx" name="img" type="text" value="${item.img}"><br>
                                    <label for="title">Title</label><br>
                                    <input class="inputx" name="title" type="text" value="${item.title}"><br>
                                    <label for="adminname">Admin Name</label><br>
                                    <input class="inputx" name="adminname" type="text" value="${adminnameload}"><br>
                                    <label for="reporttype">Report Type</label>
                                    <br>
                                    <select name="reporttype" class="input">
                                        <option>Delete post</option>
                                        <option>Edit post</option>
                                    </select>
                                    <br><br><br>
                                    <input class="input" type="submit" value="Send Report">
                                </form>
                            </blockquote>
                        </div>
                    </section>
                </td>
            `;
            dataContainer.appendChild(itemElement);
        });
        
        
    } catch (error) {
        console.error('Data fetch error:', error);
    }
}

function searchData() {
    const searchInput1 = document.querySelector("#search1").value;
    displayData(searchInput1); 
}


displayData();

function sendbtnonreport(index) {
    const allDrops = document.querySelectorAll('.drop.vcc');
    allDrops.forEach(drop => {
        drop.style.display = 'none';
    });

    const specificDrop = document.getElementById(`drop-${index}`);
    if (specificDrop) {
        specificDrop.style.display = 'block';
    }
}





var loginbox = sessionStorage.getItem("loginbox");

document.getElementById("login").style.display=loginbox;
function login(){
    var admin = ["nahidhk","admin","alshahed"];

    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    if (admin.includes(username) && password == "516148") {
        document.getElementById("login").style.display="none";
        sessionStorage.setItem("loginbox","none");
        localStorage.setItem("adminname",username);
    } else {
        alert("Error Username And Password!");
    }
}


