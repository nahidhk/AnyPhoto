<?php

$username = $_POST['username'];
$date = $_POST['date'];
$img = $_POST['img'];
$title = $_POST['title'];
$adminname = $_POST['adminname'];
$reporttype = $_POST['reporttype'];


$data = array(
    'username' => $username,
    'date' => $date,
    'img' => $img,
    'title' => $title,
    'adminname' => $adminname,
    'reporttype' => $reporttype
);


$file = 'report.json';
if(file_exists($file)){
    $current_data = file_get_contents($file);
    $array_data = json_decode($current_data, true);
} else {
    $array_data = array();
}


$array_data[] = $data;


file_put_contents($file, json_encode($array_data, JSON_PRETTY_PRINT));

echo "<center><h1>Your Report Data Monitaring in <i>Juthi Sultana</i> with 12h </h1></center>";
?>
